%%  清空环境变量
warning off             % 关闭报警信息
close all               % 关闭开启的图窗
clear                   % 清空变量
clc                     % 清空命令行

%%  导入数据
res = xlsread('数据7.xlsx');
%% 划分训练集和测试集%
temp = randperm(1200);

P_train = res(temp(1: 900), 1: 5)';
T_train = res(temp(1: 900),6)';
M = size(P_train, 2);

P_test = res(temp(901: end), 1: 5)';
T_test = res(temp(901: end),6)';
N = size(P_test, 2);
%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test  = mapminmax('apply', P_test, ps_input);
t_train = ind2vec(T_train);
t_test  = ind2vec(T_test );
%% 节点个数
inputnum  = size(p_train, 1); % 输入层节点数
hiddennum = 15;                % 隐藏层节点数
outputnum = size(t_train, 1); % 输出层节点数

%% 构建网络
net = newff(p_train, t_train, hiddennum);

%% 设置训练参数
net.trainParam.epochs     = 30;      % 训练次数
net.trainParam.goal       = 1e-4;     % 目标误差
net.trainParam.lr         = 0.01;     % 学习率
net.trainParam.showWindow = 0;        % 关闭窗口

%%  参数设置
fun = @getObjValue;                                 % 目标函数
dim = inputnum * hiddennum + hiddennum * outputnum + ...
    hiddennum + outputnum;                          % 优化参数个数
lb  = -1 * ones(1, dim);                            % 优化参数目标下限
ub  =  1 * ones(1, dim);                            % 优化参数目标上限
pop = 6;                                            % 数量
Max_iteration = 30;                                 % 最大迭代次数   

%% 优化算法
[Best_score,Best_pos,  curve] = GWO(pop, Max_iteration, lb, ub, dim, fun); 

%% 把最优初始阀值权值赋予网络预测
w1 = Best_pos(1 : inputnum * hiddennum);
B1 = Best_pos(inputnum * hiddennum + 1 : inputnum * hiddennum + hiddennum);
w2 = Best_pos(inputnum * hiddennum + hiddennum + 1 : inputnum * hiddennum + hiddennum + hiddennum*outputnum);
B2 = Best_pos(inputnum * hiddennum + hiddennum + hiddennum * outputnum + 1 : ...
    inputnum * hiddennum + hiddennum + hiddennum * outputnum + outputnum);

net.Iw{1, 1} = reshape(w1, hiddennum, inputnum);
net.Lw{2, 1} = reshape(w2, outputnum, hiddennum);
net.b{1}     = reshape(B1, hiddennum, 1);
net.b{2}     = B2';

%% 网络训练
net.trainParam.showWindow = 1;        % 打开窗口
net = train(net, p_train, t_train);
%% BP网络预测
t_sim1 = sim(net, p_train);
t_sim2 = sim(net, p_test);

%%  数据反归一化
T_sim1 = vec2ind(t_sim1);
T_sim2 = vec2ind(t_sim2);

%%  数据排序
[T_train, index_1] = sort(T_train);
[T_test , index_2] = sort(T_test );

T_sim1 = T_sim1(index_1);
T_sim2 = T_sim2(index_2);

%%  性能评价
error1 = sum((T_sim1 == T_train)) / M * 100 ;
error2 = sum((T_sim2 == T_test )) / N * 100 ;

%% 优化曲线
figure
plot(curve, 'linewidth',1.5);
title('GWO-BP')
xlabel('The number of iterations')
ylabel('Fitness')
grid on;
%%  绘图
figure
plot(1: M, T_train, 'r*', 1: M, T_sim1, 'bo', 'LineWidth', 1)
legend('真实值', 'GWO-BP预测值')
xlabel('预测样本')
ylabel('预测结果')
string = {'训练集预测结果对比'; ['准确率=' num2str(error1) '%']};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r*', 1: N, T_sim2, 'bo', 'LineWidth', 1)
legend('真实值', 'GWO-BP预测值')
xlabel('预测样本')
ylabel('预测结果')
string = {'测试集预测结果对比'; ['准确率=' num2str(error2) '%']};
title(string)
xlim([1, N])
grid

%%  混淆矩阵
figure
cm = confusionchart(T_train, T_sim1);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
    
figure
cm = confusionchart(T_test, T_sim2);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';


   %%  绘图
figure
plot(1: M, T_train, 'r*', 1: M, T_sim1, 'bo', 'LineWidth', 1)
legend('真实值', 'GWO-BP预测值')
xlabel('预测样本')
ylabel('预测结果')
string = {'训练集预测结果对比'; ['准确率=' num2str(error1) '%']};
title(string)
xlim([1, M])
grid

figure
plot(1: N, T_test, 'r*', 1: N, T_sim2, 'bo', 'LineWidth', 1)
legend('真实值', 'GWO-BP预测值')
xlabel('预测样本')
ylabel('预测结果')
string = {'测试集预测结果对比'; ['准确率=' num2str(error2) '%']};
title(string)
xlim([1, N])
grid

%%  混淆矩阵
figure
cm = confusionchart(T_train, T_sim1);
cm.Title = 'Confusion Matrix for Train Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
    
figure
cm = confusionchart(T_test, T_sim2);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';

  M = confusionmat(T_test, T_sim2);
   M = M';
   precision = diag(M)./(sum(M,2) + 0.0001); 
   recall = diag(M)./(sum(M,1)+0.0001)';
   precision = mean(precision);
   recall = mean(recall);
   score = 2*precision*recall/(precision + recall);

